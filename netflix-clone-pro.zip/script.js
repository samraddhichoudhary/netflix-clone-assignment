document.getElementById("start-btn").addEventListener("click", function () {
  alert("Thank you! You have signed up.");
});
